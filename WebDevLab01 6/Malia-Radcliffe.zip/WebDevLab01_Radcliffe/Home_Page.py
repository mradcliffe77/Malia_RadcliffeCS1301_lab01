import streamlit as st
st.set_page_config(initial_sidebar_state="expanded")


# Title of App
st.title("Web Development Lab01")

# Assignment Data 
# TODO: Fill out your team number, section, and team members

st.header("CS 1301")
st.subheader("Web Development - Section A")
st.subheader("Malia Radcliffe")


# Introduction
# TODO: Write a quick description for all of your pages in this lab below, in the form:
#       1. **Page Name**: Description
#       2. **Page Name**: Description
#       3. **Page Name**: Description
#       4. **Page Name**: Description

st.write("""
Welcome to our Streamlit Web Development Lab01 app! You can navigate between the pages using the sidebar to the left. The following pages are:

1. **Portfolio**: An introduction to me, my academic status, acquired skills, and past work experience.
2. **Quiz**: A soon to be quiz looking for user input

""")

